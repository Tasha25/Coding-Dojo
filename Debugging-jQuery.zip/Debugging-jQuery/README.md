Debugging-jQuery - My errors fixed
================

I believed the errors was that both images slide down when the h5 was clicked. I
separated it out.

Also, I added semicolons to the end of each statement. 
